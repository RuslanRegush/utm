<?php
class EventDispatcher {
    protected $observers = [];

    public function addObserver(Observer $observer, $event) {
        $this->observers[$event][] = $observer;
    }

    public function removeObserver(Observer $observer, $event) {
        if (!empty($this->observers[$event])) {
            $index = array_search($observer, $this->observers[$event]);
            if ($index !== false) {
                unset($this->observers[$event][$index]);
            }
        }
    }

    public function notifyObservers($event, $data = null) {
        if (!empty($this->observers[$event])) {
            foreach ($this->observers[$event] as $observer) {
                $observer->update($data);
            }
        }
    }
}
class UserRegisteredObserver implements Observer {
    public function update($data) {
        echo "New user registered: $data";
    }
}

// Create an event dispatcher
$dispatcher = new EventDispatcher();

// Register observers for specific events
$dispatcher->addObserver(new UserRegisteredObserver(), 'user_registered');

// Simulate a new user registration event
$userData = ['username' => 'john_doe', 'email' => 'john@example.com'];
$

?>