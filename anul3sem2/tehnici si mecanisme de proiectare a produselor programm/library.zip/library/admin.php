<?php 
  include 'config/db_connect.php';
  $dbInstance = Database::getInstance();
  $conn = $dbInstance->getConnection();



$sql ='SELECT id,name,autor,price FROM books';

// facem query in alta variabila
$result = mysqli_query($conn,$sql);

// returnarea rindului in array
$books = mysqli_fetch_all($result, MYSQLI_ASSOC);
//eliberarea memoriei
mysqli_free_result($result);
//inchidem conexiunea
//mysql_close($conn);
?>
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Library</title>
</head>
	<?php include('pages/header.php'); ?>
		
<h4 class="center grey-text">Books</h4>
	<div class="container">
		<div class="row">
			<?php foreach($books as $book){ ?>
			<div class="col s6 md3">
				<div class="card z-depth-0">
					<div class="card-content center">
						<h6>Title: <?php echo htmlspecialchars($book['name']);	?></h6>
						<div>Author: <?php echo htmlspecialchars($book['autor']); ?></div>
					</div>
					<div class="card-action">
						<table>
							<td><p class="brand-text">Price <?php echo htmlspecialchars($book['price']);	?> $</p></td>
							<td><a class="brand-text" href="update.php?id=<?php echo htmlspecialchars($book['id']); ?>">UPDATE</a></td>
							<td><a class="brand-text" href="delete.php?id=<?php echo htmlspecialchars($book['id']); ?>">DELETE</a></td>
						</table>
						
						
					
					</div>
					
				</div>
			</div>
			<?php } ?>
		</div>
	</div>

	<?php include('pages/footer.php'); ?>
</html>