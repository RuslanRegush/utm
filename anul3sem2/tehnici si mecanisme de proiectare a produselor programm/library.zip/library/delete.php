<?php
include 'config/db_connect.php';
$dbInstance = Database::getInstance();
$conn = $dbInstance->getConnection();

if (isset($_GET['id'])) {
    $id_to_delete = mysqli_real_escape_string($conn, $_GET['id']);

    // Create SQL query to delete a record
    $sql = "DELETE FROM books WHERE id = $id_to_delete";

    // Execute query
    if (mysqli_query($conn, $sql)) {
        // Successful deletion
        header('Location: admin.php'); // Redirect to the main page after deletion
    } else {
        // Error in deletion
        echo 'Error deleting record: ' . mysqli_error($conn);
    }

    // Close connection
    mysqli_close($conn);
} else {
    // If no book id is provided, redirect to the main page
    header('Location: admin.php');
}
?>
