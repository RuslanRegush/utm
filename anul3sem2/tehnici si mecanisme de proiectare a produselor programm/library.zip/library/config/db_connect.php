<?php 
	       //conectarea la baza de date
        $conn = mysqli_connect('localhost','ruslan','pass123','library');
        // verificare daca este conexiune cu baza de date
        if(!$conn){
            echo 'Connection error:' . mysqli_connect_error();
        }
        class Database {
            private static $instance = null;
            private $conn;
        
            private $host = 'localhost';
            private $user = 'ruslan';
            private $password = 'pass123';
            private $dbname = 'library';
        
            private function __construct() {
                $this->conn = new mysqli($this->host, $this->user, $this->password, $this->dbname);
        
                if ($this->conn->connect_error) {
                    die("Connection failed: " . $this->conn->connect_error);
                }
            }
        
            public static function getInstance() {
                if (self::$instance == null) {
                    self::$instance = new Database();
                }
        
                return self::$instance;
            }
        
            public function getConnection() {
                return $this->conn;
            }
        }
        
?>