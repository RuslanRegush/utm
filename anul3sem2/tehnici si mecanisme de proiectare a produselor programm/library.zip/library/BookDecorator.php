<?php
interface Book {
    public function getTitle();
    public function getAuthor();
    public function getPrice();
}

class BasicBook implements Book {
    protected $title;
    protected $author;
    protected $price;

    public function __construct($title, $author, $price) {
        $this->title = $title;
        $this->author = $author;
        $this->price = $price;
    }

    public function getTitle() {
        return $this->title;
    }

    public function getAuthor() {
        return $this->author;
    }

    public function getPrice() {
        return $this->price;
    }
}

class SpecialOfferBookDecorator implements Book {
    protected $book;

    public function __construct(BasicBook $book) {
        $this->book = $book;
    }

    public function getTitle() {
        return $this->book->getTitle() . ' (Special Offer)';
    }

    public function getAuthor() {
        return $this->book->getAuthor();
    }

    public function getPrice() {
        return $this->book->getPrice() * 0.9; // 10% discount
    }
}

?>