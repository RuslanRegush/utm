<?php 
include 'config/db_connect.php';
$dbInstance = Database::getInstance();
$conn = $dbInstance->getConnection();
$login = $password = '';

$sql ='SELECT email,password FROM user';

// facem query in alta variabila
$result = mysqli_query($conn,$sql);

//eliberarea memoriei
mysqli_free_result($result);
?>

<!DOCTYPE html>
<html>
<style type="text/css">
	.brand{
		background: #cbb09c !important;
	}
	.brand-text{
		color: #cbb09c !important;
	}
	
</style>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<title>Login</title>
</head>
<body>

<div class="center brand-logo brand-text">>
 <h1 >WELLCOME</h1></div>
 <div class="left">
 	<div class="brand-text">
 		 <label>Email</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($login); ?>">
            <label>Password</label>
            <input type="text" name="author" value="<?php echo htmlspecialchars($password); ?>">
 	</div>
 </div>
</body>
</html>