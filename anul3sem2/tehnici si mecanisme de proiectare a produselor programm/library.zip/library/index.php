<?php 
include 'config/db_connect.php';
$dbInstance = Database::getInstance();
$conn = $dbInstance->getConnection();

$login = $password = '';

if(isset($_POST['button1'])) {
    $login = mysqli_real_escape_string($conn, $_POST['login']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    if(empty($login) || empty($password)) {
        echo 'Please enter both email and password';
    } else {
        $sql = "SELECT id, name, email, password FROM user WHERE email = '$login'";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $row = mysqli_fetch_assoc($result);
            if ($row) {
                if ($row['password'] == $password) {
                    $userId = $row['id'];
                    $userName = $row['name'];

                    if ($login == "admin@gmail.com" && $password == "Admin") {
                        header('Location: admin.php');
                        exit();
                    } else {
                        header("Location: main.php?userId=$userId&userName=$userName");
                        exit();
                    }
                } else {
                    echo 'Invalid password';
                }
            } else {
                echo 'User not found';
            }
        } else {
            echo 'Query error: ' . mysqli_error($conn);
        }

        mysqli_free_result($result);
    }
}
if(isset($_POST['button1'])) {
    // Your existing login logic here
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <title>Login</title>
    <style type="text/css">
        
        .brand {
            background: #cbb09c !important;
        }

        .brand-text {
            color: #cbb09c !important;
        }

        .login-container {
            text-align: center;
            margin-top: 20px;
        }

        form {
            display: inline-block;
            text-align: left;
        }
    </style>
</head>

<body>

    <div class="center brand-logo brand-text">
        <h1>WELCOME</h1>
    </div>

    <div class="login-container">
        <form method="post" action="">
            <div class="brand-text">
                <label>Email</label>
                <input type="text" name="login" value="<?php echo htmlspecialchars($login); ?>">
                <label>Password</label>
                <input type="password" name="password" value="<?php echo htmlspecialchars($password); ?>">
            </div>

            <input type="submit" name="button1" class="button" value="Login" />
        </form>

        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>

</html>