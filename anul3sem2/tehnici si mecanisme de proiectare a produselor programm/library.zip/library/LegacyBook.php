<?php 
	   
class LegacyBook {
    public function oldCreate($bookName, $bookAuthor, $bookCost) {
        // Simulates the creation of a book in the legacy system
        return "LegacyBook: $bookName by $bookAuthor costs $bookCost";
    }
}
?>