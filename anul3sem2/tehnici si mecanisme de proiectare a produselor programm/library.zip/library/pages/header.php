<head>
	<title>Books</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<style type="text/css">
	.brand{
		background: #cbb09c !important;
	}
	.brand-text{
		color: #cbb09c !important;
	}
	form{
		max-width: 460px;
		margin: 20px;
		padding: 20px;
	}
	
</style>
</head>
	<body class="grey">
		<nav class="white z-depth-0">
			<div class="container">
				<a href="admin.php" class="brand-logo brand-text">Books</a>
				<ul id="nav-mobile" class="right hide-on-small-and-down">
					<li><a href="add.php" class="btn brand z-depth-0">Add a book</a></li>
					<li><a href="index.php" class="btn brand z-depth-0">Exit</a></li>
				</ul>
			</div>
		</nav>
		
	</body>
