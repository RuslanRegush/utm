
<footer class="section">
	<div class="center black-text">APLICATAIE CRUD</div>
</footer>
</body>