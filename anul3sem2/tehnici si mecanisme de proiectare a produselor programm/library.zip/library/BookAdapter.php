<?php
class BookAdapter {
    private $legacyBook;

    public function __construct(LegacyBook $legacyBook) {
        $this->legacyBook = $legacyBook;
    }

    public function createBook($title, $author, $price) {
        return $this->legacyBook->oldCreate($title, $author, $price);
    }
}
?>