<?php
include 'Book.php';
 include 'config/db_connect.php';        // Singleton for DB connection
include 'BookFactory.php';     // Factory Method for Book creation
include 'LegacyBook.php';      // Legacy system class
include 'BookAdapter.php';     // Adapter for legacy system

$conn = Database::getInstance()->getConnection();
$bookFactory = new ConcreteBookFactory();

if (isset($_POST['submit'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    
    // Create a new Book object using the factory
    $newBook = $bookFactory->createBook($title, $author, $price);

    // Insert the new book into the database
    $sql = "INSERT INTO books (name, autor, price) VALUES ('$title', '$author', '$price')";
    
    if (mysqli_query($conn, $sql)) {
        // Use the Adapter to interact with the legacy system
        $legacyBook = new LegacyBook();
        $adapter = new BookAdapter($legacyBook);
        $legacyBookDetails = $adapter->createBook($title, $author, $price);

        // Display the legacy book details or use them as needed
        echo $legacyBookDetails;
        
        header('Location: admin.php');
    } else {
        echo 'Error: ' . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<?php include('pages/header.php'); ?>
<section class="container grey-text">
    <h4 class="center" style="color: white;">Add a book</h4>
    <div class="center">
        <form class="white" action="add.php" method="POST" style="margin: auto; width: 50%;">
            <label>Title</label>
            <input type="text" name="title">
            <label>Author</label>
            <input type="text" name="author">
            <label>Price</label>
            <input type="text" name="price">
            <div class="center">
                <input type="submit" name="submit" value="Submit" class="btn brand z-depth-0">
            </div>
        </form>
    </div>
</section>
<?php include('pages/footer.php'); ?>
</html>
