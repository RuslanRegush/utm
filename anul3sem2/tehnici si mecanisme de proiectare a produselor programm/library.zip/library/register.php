<?php 
include 'config/db_connect.php';
$dbInstance = Database::getInstance();
$conn = $dbInstance->getConnection();

$login = $password = $name = $surname = '';
$errors = array('name' => '', 'surname' => '', 'login' => '', 'password' => '');

if(isset($_POST['button1'])) {
    if(empty($_POST['name'])) {
        $errors['name'] = 'First Name is required';
    } else {
        $name = $_POST['name'];
    }

    if(empty($_POST['surname'])) {
        $errors['surname'] = 'Last Name is required';
    } else {
        $surname = $_POST['surname'];
    }
    if(empty($_POST['login'])) {
        $errors['login'] = 'Email is required';
    } else {
        $login = $_POST['login'];
        $sql = "SELECT * FROM user WHERE email = '$login'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0) {
            $errors['login'] = 'Email already in use';
        }
    }
    if(empty($_POST['password'])) {
        $errors['password'] = 'Password is required';
    } else {
        $password = $_POST['password'];
    }

    if(!array_filter($errors)) {
        $sql = "INSERT INTO user (name, surname, email, password) VALUES ('$name', '$surname', '$login', '$password')";
        if(mysqli_query($conn, $sql)) {
            header('Location: index.php'); 
        } else {
            echo 'Query error: ' . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <title>Login</title>
    <style type="text/css">
        
        .brand {
            background: #cbb09c !important;
        }

        .brand-text {
            color: #cbb09c !important;
        }

        .login-container {
            text-align: center;
            margin-top: 20px;
        }

        form {
            display: inline-block;
            text-align: left;
        }
    </style>
</head>

<body>

    <div class="center brand-logo brand-text">
        <h1>WELCOME A NEW USER</h1>
    </div>

    <div class="login-container">
        <form method="post" action="">
            <div class="brand-text">
            	<label>First Name</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>">
                <div class="red-text"><?php echo $errors['name']; ?></div>

                <label>Last Name</label>
                <input type="text" name="surname" value="<?php echo htmlspecialchars($surname); ?>">
                <div class="red-text"><?php echo $errors['surname']; ?></div>

                <label>Email</label>
                <input type="text" name="login" value="<?php echo htmlspecialchars($login); ?>">
                <div class="red-text"><?php echo $errors['login']; ?></div>

                <label>Password</label>
                <input type="password" name="password" value="<?php echo htmlspecialchars($password); ?>">
                <div class="red-text"><?php echo $errors['password']; ?></div>
            </div>

            <input type="submit" name="button1" class="button " value="New User" />
        </form>
    </div>
</body>

</html>