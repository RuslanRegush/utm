<?php 
include 'config/db_connect.php';
$dbInstance = Database::getInstance();
$conn = $dbInstance->getConnection();

$userId = $userName = '';

if (isset($_GET['userId']) && isset($_GET['userName'])) {
    $userId = $_GET['userId'];
    $userName = $_GET['userName'];
}

$sql = 'SELECT id, name, autor, price FROM books';

$result = mysqli_query($conn, $sql);
$books = mysqli_fetch_all($result, MYSQLI_ASSOC);

mysqli_free_result($result);
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<style type="text/css">
	.brand{
		background: #cbb09c !important;
	}
	.brand-text{
		color: #cbb09c !important;
	}
	form{
		max-width: 460px;
		margin: 20px;
		padding: 20px;
	}
	
</style>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Library</title>
</head>
		<body class="grey">
			<nav class="white z-depth-0">
			<div class="container">
				<a href="#" class="brand-logo brand-text">Welcome <?php echo $userName; ?></a>
				<ul id="nav-mobile" class="right hide-on-small-and-down">
					<li><a href="index.php" class="btn brand z-depth-0">Exit</a></li>
				</ul>
			</div>
		</nav>
			<h4 class="center grey-text">Books</h4>
	<div class="container">
		<div class="row">
			<?php foreach($books as $book){ ?>
			<div class="col s6 md3">
				<div class="card z-depth-0">
					<div class="card-content center">
						<h6>Title: <?php echo htmlspecialchars($book['name']);	?></h6>
						<div>Author: <?php echo htmlspecialchars($book['autor']); ?></div>
					</div>
					
					<div class="card-action ">
						
						<p class="brand-text">Price <?php echo htmlspecialchars($book['price']);	?> $</p>
					</div>
					
				</div>
			</div>
			<?php } ?>
		</div>
	</div>

	<?php include('pages/footer.php'); ?>
</html>