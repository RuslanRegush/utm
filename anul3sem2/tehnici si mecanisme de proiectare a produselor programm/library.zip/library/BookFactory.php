<?php
abstract class BookFactory {
    abstract public function createBook($title, $author, $price);
}

class ConcreteBookFactory extends BookFactory {
    public function createBook($title, $author, $price) {
        return new Book($title, $author, $price);
    }
}
?>
