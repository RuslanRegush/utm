<?php
// Implement the interface and create concrete product objects
class MysqlDatabaseFactory implements AbstractDatabaseFactory {
    public function createConnection() {
        return new MysqlConnection();
    }

    public function createQueryExecutor() {
        return new MysqlQueryExecutor();
    }
}

?>