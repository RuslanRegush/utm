<?php 
include 'config/db_connect.php';
$dbInstance = Database::getInstance();
$conn = $dbInstance->getConnection();

// Check if the 'id' parameter is set in the URL
if(isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Fetch the book details based on the id
    $sql = "SELECT id, name, autor, price FROM books WHERE id = $id";
    $result = mysqli_query($conn, $sql);

    // Check if the query was successful
    if($result) {
        // Fetch the book details
        $book = mysqli_fetch_assoc($result);
        // Free the result set
        mysqli_free_result($result);
    } else {
        echo 'Error: '.mysqli_error($conn);
    }
}

// Handle form submission for updates
if(isset($_POST['update'])) {
    $updatedTitle = mysqli_real_escape_string($conn, $_POST['title']);
    $updatedAuthor = mysqli_real_escape_string($conn, $_POST['author']);
    $updatedPrice = mysqli_real_escape_string($conn, $_POST['price']);

    // Update the book details in the database
    $updateSql = "UPDATE books SET name='$updatedTitle', autor='$updatedAuthor', price='$updatedPrice' WHERE id = $id";

    if(mysqli_query($conn, $updateSql)) {
        // Redirect to the index page after successful update
        header('Location: admin.php');
    } else {
        echo 'Error updating record: '.mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<?php include('pages/header.php'); ?>
<section class="container grey-text">
    <h4 class="center" style="color: white;">Update Book</h4>
    <div class="center">
        <form class="white" action="update.php?id=<?php echo $id; ?>" method="POST" style="margin: auto; width: 50%;">
            <label>Title</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($book['name']); ?>">
            <label>Author</label>
            <input type="text" name="author" value="<?php echo htmlspecialchars($book['autor']); ?>">
            <label>Price</label>
            <input type="text" name="price" value="<?php echo htmlspecialchars($book['price']); ?>">
            <div class="center">
                <input type="submit" name="update" value="Update" class="btn brand z-depth-0"> 
            </div>
        </form>
    </div>
</section>
<?php include('pages/footer.php'); ?>
</html>
