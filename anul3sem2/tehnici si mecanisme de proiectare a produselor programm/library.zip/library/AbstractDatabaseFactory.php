<?php
interface AbstractDatabaseFactory {
    public function createConnection();
    public function createQueryExecutor();
}
?>