#include "lab_1_app.h"

void lab_1_app_setup(){

}

void lab_1_app_loop(){

}