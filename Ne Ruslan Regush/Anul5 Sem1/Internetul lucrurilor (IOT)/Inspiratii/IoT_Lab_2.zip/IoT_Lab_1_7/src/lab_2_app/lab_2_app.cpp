#include "lab_2_app.h"

#include "srv_serial_stdio/srv_serial_stdio.h"


void lab_2_app_setup()
{
    srv_serial_setup();
    printf("Hello, World!\n");
}

void lab_2_app_loop()
{
}