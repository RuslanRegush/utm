#ifndef LAB_2_APP_H
#define LAB_2_APP_H

// Include any necessary libraries here

// Declare any global variables or constants here

// Declare function prototypes here

void lab_2_app_setup();
void lab_2_app_loop();

#endif // LAB_2_APP_H