
#include "srv_serial_stdio.h"

// 1. Include device driver
#include <Arduino.h>

char srv_serial_get_char()
{
    // Declare a variable to store the character
    char c;
    // Wait until a character is available 
    while (!Serial.available()); 
    // Read the character from the serial monitor
    c = Serial.read();
    // Return the character
    return c;
}

void srv_serial_put_char(char c)
{
    //Print the character to the serial monitor
    Serial.write(c);
}
