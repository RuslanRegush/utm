#ifndef LAB_1_APP_H
#define LAB_1_APP_H

// Include any necessary libraries here

// Define any constants or global variables here

// Declare function prototypes here
void lab_1_app_setup();
void lab_1_app_loop();

#endif // LAB_1_APP_H