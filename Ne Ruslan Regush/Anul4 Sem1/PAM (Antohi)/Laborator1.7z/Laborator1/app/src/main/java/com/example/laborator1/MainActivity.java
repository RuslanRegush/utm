package com.example.laborator1;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Inițializați elementele interfeței grafice
        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button buttonSearch = findViewById(R.id.buttonSearch);
        Button button4 = findViewById(R.id.button4);
        editText = findViewById(R.id.editText);
        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onButtonSearchClick();
            }
        });
    }

    public void onButtonSearchClick() {
        // Obținerea textului introdus în TextBox
        String searchKeyword = editText.getText().toString();

        // Inițiarea căutarii în Google utilizând browserul implicit al dispozitivului
        if (!searchKeyword.isEmpty()) {
            String searchUrl = "https://www.google.com/search?q=" + Uri.encode(searchKeyword);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl));
            startActivity(intent);
        }
    }

    Button button4 = findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
        public void onClickClear(View v) {
            // Ascunde lista când se apasă pe buton
            hideAnimalList();
        }
    });


    private void initAnimalList() {
        animalList = new ArrayList<>();
        animalList.add(new Animal("Papagal", "Pasăre colorată și inteligentă."));
        animalList.add(new Animal("Leu", "Regele junglei."));
        animalList.add(new Animal("Tigru", "Felidă cu dungi caracteristice."));
        animalList.add(new Animal("Pinguin", "Pasăre nonzburătoare adaptată la viața în apă."));
        animalList.add(new Animal("Aligator", "Reptilă semi-acvatică."));
    }

    private void displayAnimalList() {
        List<String> animalNames = new ArrayList<>();
        for (Animal animal : animalList) {
            animalNames.add(animal.getHeadTitle());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, animalNames);
        listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Animal selectedAnimal = animalList.get(position);
            showAnimalDetails(selectedAnimal);
        });
    }

    private void showAnimalDetails(Animal animal) {
        String details = animal.getContentOption();
        Toast.makeText(this, details, Toast.LENGTH_SHORT).show();
    }

    private void hideAnimalList() {
        // Facem lista invizibilă
        listView.setVisibility(View.GONE);
    }
}